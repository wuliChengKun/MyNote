package cn.edu.ujn.myself.c;

import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//Alt + /
//Ctrl + 1
@WebServlet("/login")
public class LoginServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//super.doPost(req, resp);
		String username = req.getParameter("username");
		String pwd = req.getParameter("pwd");
		try {
			//org.gjt.mm.mysql.Driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/javaee?serverTimezone=UTC";
			Connection con = DriverManager.getConnection(url, "root","123456");
			Statement s = con.createStatement();
			ResultSet rs = s.executeQuery("select * from user where username='"	+ username + "' and password='" + pwd + "'");
			if (rs.next()) {
				resp.sendRedirect("success.jsp");
			}else
				resp.sendRedirect("login.jsp");
			
			rs.close();
			s.close();
			con.close();
		}catch(Exception e) {
			//TODO: handle exception
		}
				
	}
}
